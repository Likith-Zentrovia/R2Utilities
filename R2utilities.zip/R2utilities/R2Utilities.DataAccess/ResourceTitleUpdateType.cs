namespace R2Utilities.DataAccess;

public enum ResourceTitleUpdateType
{
	Equal = 1,
	RittenhouseEqualR2TitleAndSub,
	R2EqualRittenhouseTitleAndSub,
	NotExist,
	DifferentSub,
	RittenhouseSubNull,
	R2SubNull,
	Other
}
