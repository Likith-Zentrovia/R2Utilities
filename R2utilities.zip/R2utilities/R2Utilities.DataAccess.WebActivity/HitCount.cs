namespace R2Utilities.DataAccess.WebActivity;

public class HitCount
{
	public virtual int Count { get; set; }
}
