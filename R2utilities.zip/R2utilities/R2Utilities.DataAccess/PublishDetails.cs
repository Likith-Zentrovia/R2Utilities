namespace R2Utilities.DataAccess;

public class PublishDetails
{
	public double rate { get; set; }
}
