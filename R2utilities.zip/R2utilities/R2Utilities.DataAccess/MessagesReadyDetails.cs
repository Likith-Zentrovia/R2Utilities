namespace R2Utilities.DataAccess;

public class MessagesReadyDetails
{
	public double rate { get; set; }
}
