namespace R2Utilities.DataAccess;

public class UserIdAndInstitutionId
{
	public int UserId { get; set; }

	public int InstitutionId { get; set; }
}
