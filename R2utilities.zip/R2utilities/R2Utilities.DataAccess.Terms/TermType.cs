namespace R2Utilities.DataAccess.Terms;

public enum TermType
{
	Tabers,
	Disease,
	DiseaseSynonym,
	Drug,
	DrugSynonym,
	Keyword
}
