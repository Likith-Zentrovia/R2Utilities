namespace R2Utilities.Tasks.ContentTasks;

public enum ResourceContentDirectoryType
{
	Xml,
	Html,
	Images,
	Media
}
