namespace R2Utilities.DataAccess;

public enum TrialNotice
{
	First = 9,
	Second = 3,
	Final = 0,
	Extension = -1
}
