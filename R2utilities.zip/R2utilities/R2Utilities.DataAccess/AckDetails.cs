namespace R2Utilities.DataAccess;

public class AckDetails
{
	public double rate { get; set; }
}
