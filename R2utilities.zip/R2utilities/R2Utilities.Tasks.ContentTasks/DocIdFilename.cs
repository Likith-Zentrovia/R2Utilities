namespace R2Utilities.Tasks.ContentTasks;

public class DocIdFilename
{
	public int Id { get; set; }

	public string Name { get; set; }

	public bool IsInvalidPath { get; set; }
}
