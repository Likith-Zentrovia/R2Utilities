namespace R2Utilities.Tasks.DataConversion;

public class LimitCriteria
{
	public int Discipline { get; set; }

	public int Resource { get; set; }

	public int Library { get; set; }

	public int ReserverShelf { get; set; }
}
