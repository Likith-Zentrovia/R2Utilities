namespace R2Utilities.DataAccess;

public class MessagesUnacknowledgedDetails
{
	public double rate { get; set; }
}
