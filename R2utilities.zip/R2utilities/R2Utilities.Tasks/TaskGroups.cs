namespace R2Utilities.Tasks;

public class TaskGroups
{
	public static string[] Names = new string[8] { "None", "Content Loading", "Diagnostics & Maintenance", "CustomerEmails", "RittenhouseOnlyEmails", "InternalSystemEmails", "Feeds", "Deprecated" };
}
