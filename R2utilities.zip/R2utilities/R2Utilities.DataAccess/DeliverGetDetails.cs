namespace R2Utilities.DataAccess;

public class DeliverGetDetails
{
	public double rate { get; set; }
}
