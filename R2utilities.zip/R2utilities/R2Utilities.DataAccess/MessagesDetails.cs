namespace R2Utilities.DataAccess;

public class MessagesDetails
{
	public double rate { get; set; }
}
