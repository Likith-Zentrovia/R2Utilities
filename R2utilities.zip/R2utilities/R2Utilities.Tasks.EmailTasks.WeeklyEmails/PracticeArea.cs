namespace R2Utilities.Tasks.EmailTasks.WeeklyEmails;

public enum PracticeArea
{
	Medicine = 1,
	Nursing,
	AlliedHealth
}
