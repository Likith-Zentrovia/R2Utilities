namespace R2Utilities.Tasks.DataConversion;

public class SearchCriteria
{
	public string Type { get; set; }

	public string Phrase { get; set; }
}
