namespace R2Utilities.DataAccess;

public class DeliverDetails
{
	public double rate { get; set; }
}
